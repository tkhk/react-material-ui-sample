export const TODOS = {
  todos: [
    { id: 1, status: "TODO", title: "todo 1", body: "aaaaaaaaaa" },
    { id: 2, status: "TODO", title: "todo 2", body: "bbbbbbbbbb" },
    { id: 3, status: "TODO", title: "todo 3", body: "cccccccccc" },
    { id: 4, status: "DOING", title: "todo 4", body: "dddddddddd" },
    { id: 5, status: "DONE", title: "todo 5", body: "eeeeeeeeee" },
    { id: 6, status: "DONE", title: "todo 6", body: "ffffffffff" }
  ]
};
